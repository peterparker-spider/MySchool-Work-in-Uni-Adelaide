
Student Number : a1769334 Student Name: Chen Cao        Student Email: a1769334@student.adelaide.edu.au
Student Number : a1696670 Student Name: Guanfeng Lin  Student Email: a1696670@student.adelaide.edu.au


The WordCount folder is the root folder of this project, 
open with eclipse to run the code in standalone mode, before running program, 
you should set argument in eclipse.

For pseudo-distributed mode, run program with command like:
hadoop jar {program_name} edu.standford.cs246.wordocunt {inputdata} output_floder {length}

{program_name} = WordCount | Part2 | Part3
{inputdata}    = 100-0.txt | pg100.txt | 3399.txt
{length}       = -1 | positive integer

In particular, when the length parameter is set to a negative number, such as - 1, 
the program will display the results of words of all lengths. 
Otherwise, only the results of the specified length will be displayed



The following folder is the output of the standalone mode:
Exercise 3 10-0.txt: Wordcount/exe3output
Exercise 4 Part 1-2 pg100.txt:  Wordcount/Part2pg100output
Exercise 4 Part 1-2 3399.txt:  Wordcount/Part23399output
Exercise 4 Part 3-4 pg100.txt:  Wordcount/Part23399output
Exercise 4 Part 3-4 3399.txt:  Wordcount/Part23399output


The following folder is the output of the pseudo-distributed mode:
Exercise 3 100-0.txt: Wordcount/jar_output/output/ex3
Exercise 4 Part 1-2 pg100.txt:  Wordcount/jar_output/output/ex4_1_pg100
Exercise 4 Part 1-2 3399.txt:  Wordcount/jar_output/output/ex4_1_3399
Exercise 4 Part 3-4 pg100.txt:  Wordcount/jar_output/output/ex4_3_pg100
Exercise 4 Part 3-4 3399.txt:  Wordcount/jar_output/output/ex4_3_3399


