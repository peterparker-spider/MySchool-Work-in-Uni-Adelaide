var express = require('express');
var router = express.Router();
var post = [];

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});


router.post('/addpost', function(req, res, next) {
  var q1 = req.body.title;
  var q2 = req.body.post;
  post.push(req.body);

  res.send();

});

router.get('/getposts', function(req, res, next) {

  res.send(post.reverse());

});

module.exports = router;
