var express = require('express');
var router = express.Router();
var respond = "first";

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/brew', function(req, res, next) {
  var q = req.query.drink;

  if(q === "tea"){
    res.send("A delicious cup of tea!");
  }
  else if(q === "coffee"){
    res.status(418);
    res.send();
  }
  else{
    res.status(400);
    res.send();
  }

});

var fuck = 0;
router.get('/cookie', function(req, res, next) {
  fuck++;
  res.cookie('task3_1',fuck);
  res.send();

});

router.post('/pass-it-on', function(req, res, next) {
  var q = req.body.message;
  if(q == null || q == " "){
    res.status(400);
    res.send();
  }
  else{
    res.send(respond);
    respond = q;
  }
});


router.post('/combine', function(req, res, next) {
  var q = req.body.suffix;
  var q1 = req.body.lines;
  var line= "";
  for(var i= 0;i<q1.length;i++){
    line = line + q1[i] + q +"\n";
  }
  res.send(line);

});



module.exports = router;
