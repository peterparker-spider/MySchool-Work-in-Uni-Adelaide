select customer.first_name ,customer.last_name,rental.rental_date from rental JOIN customer ON
customer.customer_id = rental.customer_id
where rental.return_date is NULL order by rental.rental_date limit 1;