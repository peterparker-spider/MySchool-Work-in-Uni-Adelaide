function show_time(){
    /* 1. Create new AJAX request */
    var xhttp = new XMLHttpRequest();
    /* 4. Handle response (callback function) */
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            var time_section = document.getElementById("time");
            time_section.innerText="This page was last viewed" +this.responseText;
            /*console.log(this.responseText);*/
        }
    };
    /* 2. Open connection */
    xhttp.open("GET", "/last.txt", true);
    /* 3. Send request */
    xhttp.send();

    }

function task42(){
/* 1. Create new AJAX request */
var xhttp = new XMLHttpRequest();
/* 4. Handle response (callback function) */
xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        var color_change = document.getElementById("42");

        color_change.style.color=this.responseText;
        color_change.innerText=this.responseText;
        /*console.log(this.responseText);*/
    }
};
/* 2. Open connection */
xhttp.open("GET", "/color.txt", true);
/* 3. Send request */
xhttp.send();

}