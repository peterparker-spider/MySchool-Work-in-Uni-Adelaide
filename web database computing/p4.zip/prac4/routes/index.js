var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});



var time = " ";

router.get('/last.txt', function(req, res, next) {
  res.send(time);
  time = new Date();
});

var index = 0;

router.get('/color.html', function(req, res, next) {

  if(index == 0){
    index+=1;
    res.send(`<!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>task2-8</title>

    </head>

    <body>

    <h1 style="color:red;">red</h1>


    </body>
    </html>
`);

  }

else if(index == 1){
  index+=1;
    res.send(`<!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>task2-8</title>

    </head>

    <body>

    <h1 style="color:yellow;">yellow</h1>


    </body>
    </html>
`);

  }

else if(index == 2){
  index+=1;
    res.send(`<!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>task2-8</title>

    </head>

    <body>

    <h1 style="color:green;">green</h1>


    </body>
    </html>
`);

  }


else if(index == 3){
  index=0;
    res.send(`<!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>task2-8</title>

    </head>

    <body>

    <h1 style="color:blue;">blue</h1>


    </body>
    </html>
`);

  }
});
//task 3.3

var m_times = "";

router.get('/log.html', function(req, res, next) {

    m_times += "<li>" + new Date() + "</li>";

    var display =`
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <title>task2-8</title>

    </head>

    <body>

  <ul>
  ${m_times}
  </ul>




    </body>
    </html>
  `;
  res.send(display);

  });

var index1 = 0;

router.get('/color.txt', function(req, res, next) {

    var c = " ";
    if(index1 == 0){
      c="red";
      index1+=1;

    }

  else if(index1 == 1){
    c="yellow";
    index1+=1;

    }

  else if(index1 == 2){
    c="green";
    index1+=1;


    }


  else if(index1 == 3){
    c="blue";
    index1=0;

    }
    res.send(c);
  });

module.exports = router;