# social_planning_app

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
