function showthetime(){
   var changeText=document.getElementById("current_time");

   changeText.innerText=new Date();


}