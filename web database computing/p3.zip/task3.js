var count=1;

function time_of_mouse(){
    var times= document.getElementById("mcount");
    times.innerText=count;
    count++;


}

function post(){
      var pos_section=document.getElementById("posts");

      var text= document.getElementById("text");

      var text_words=text.value;
      
      var quantity=document.getElementById("quantity");

      var red = document.getElementById("red");

      var blue = document.getElementById("blue");

      var color = " ";

      if(red.checked == true){

          color= "color:red;"
      }
      else if(blue.checked == true){
          color="color:blue;"

      }

      var post =` 
         <p class="post-time">
           ${new Date()}
        </p>
        <p class="post-content"  style= "${color}">
           ${text_words}
        </p>
       `;
    for (var i=0;i<quantity.value; i++) {

    pos_section.innerHTML += post;

    }
     


}

function menu_switch() {
  var main=document.getElementById("main");
  var menu=document.getElementById("menu");

  if(menu.style.display == "none" ){
      menu.style.display = "block";
      main.style.display = "none";

  }
  else{
     menu.style.display="none";
     main.style.display="block";

  }


}


function background_color(){
    var body=document.getElementById("body");
    var color_input=document.getElementById("background_color");

    body.style.backgroundColor=color_input.value;


}